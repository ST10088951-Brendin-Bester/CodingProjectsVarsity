using DisasterAlleviationFoundation.Models;
using Microsoft.EntityFrameworkCore;


namespace DisasterAlleviationFoundation
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddRazorPages();

            // Add a database provider (import the Microsoft.EntityFrameworkCore namespace!)

            builder.Services.AddDbContext<DonationContext>(options => 
                options.UseSqlServer ("Server=tcp:disasteralleviationserver.database.windows.net,1433;Database=DisasterDB;Initial Catalog=disasteralleviation;Persist Security Info=False;User ID=disasteradmin;Password=Disaster15;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=True;Connection Timeout=30;"));

            var app = builder.Build();

            
            
        }
    }
}
