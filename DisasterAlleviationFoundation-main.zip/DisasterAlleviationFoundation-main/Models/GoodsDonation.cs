﻿

namespace DisasterAlleviationFoundation.Models
{
    public class GoodsDonation
    {
        public int Id { get; set; }  // Unique identifier for the donation
        public DateTime Date { get; set; }  // Date of the donation
        public int NumberOfItems { get; set; }  // Number of items donate
        public string Category { get; set; }  // Category of the donated goods
        public string Description { get; set; }  // Description of the donated item
        public bool IsAnonymous { get; set; }  // Indicates if the donor wants to remain anonymous
    }
}
