﻿namespace DisasterAlleviationFoundation.Models
{
    public class MonetaryDonation
    {
        public int Id { get; set; }  // Unique identifier for the donation
        public DateTime Date { get; set; }  // Date of the donation
        public decimal Amount { get; set; }  // Monetary amount of the donation
        public bool IsAnonymous { get; set; }  // Indicates if the donor wants to remain anonymous
    }
}
