﻿
namespace DisasterAlleviationFoundation.Models
{
    public class Disaster
    {
        public int Id { get; set; }  // Unique identifier for the disaster

        public DateTime StartDate { get; set; }  // Start date of the disaster

        public DateTime EndDate { get; set; }  // End date of the disaster

        public string Location { get; set; }  // Location of the disaster

        public string Description { get; set; }  // Description of the disaster
       
    }
}
