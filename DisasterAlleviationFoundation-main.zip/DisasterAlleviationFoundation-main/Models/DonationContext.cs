﻿using Microsoft.EntityFrameworkCore;

namespace DisasterAlleviationFoundation.Models
{
    public class DonationContext : DbContext
    {
        public DbSet<MonetaryDonation> MonetaryDonations { get; set; }
        public DbSet<GoodsDonation> GoodsDonations { get; set; }
        public DbSet<Disaster> Disasters { get; set; }

        public DonationContext(DbContextOptions options) : base(options) 
        {

        }
    }
}
