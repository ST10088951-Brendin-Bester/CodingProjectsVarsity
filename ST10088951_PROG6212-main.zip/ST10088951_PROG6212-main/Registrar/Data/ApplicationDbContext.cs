﻿#nullable disable
using Microsoft.EntityFrameworkCore;
using Registrar.Models;

namespace Registrar.Data
{
    public class ApplicationDbContext :DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }

        public DbSet<Registeruser> Registerusers { get; set; }
        public DbSet<SemesterModule> modules { get; set; }
        public DbSet<StudyRecord> StudyRecords { get; set; }

    }
}
