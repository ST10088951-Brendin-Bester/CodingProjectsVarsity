﻿#nullable disable
using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace Registrar.Models
{
    public class SemesterModule
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [Display(Name ="Semeter Code")]
        public string Code { get; set; }
        [Required]
        [Display(Name = "Semeter Name")]
        public string Name { get; set; }
        [Required]
        [Display(Name = "Semeter Credits")]
        public int Credits { get; set; }
        [Required]
        [Display(Name = "Class Hours Per Week")]
        public int ClassHoursPerWeek { get; set; }
        [Required]
        [Display(Name = "Self Study Hours Per Week")]
        public int SelfStudyHoursPerWeek { get; set; }
        [Required]
        [Display(Name = "Number of Week in Semester")]
        public int NumberofWeek { get; set; }
        [Required]
        [Display(Name = "Start date of Semester")]
        public DateTime StartDate { get; set; }
    
        public List<StudyRecord> StudyRecords { get; set; } = new List<StudyRecord>();

        public string RemainTime
        {
            get
            {
                var currentDate = DateTime.Now;
                var recordedMinutes = StudyRecords
                    .Where(record => record.Date.Date >= currentDate.Date.AddDays(-(int)currentDate.DayOfWeek))
                    .Sum(record => record.Hours * 60 + record.Minutes);

                var remainingMinutes = SelfStudyHoursPerWeek * 60 - recordedMinutes;

                return FormatRemainingTime(remainingMinutes);
            }
        }

        public string FormatRemainingTime(int remainingMinutes)
        {
            int hours = remainingMinutes / 60;
            int minutes = remainingMinutes % 60;

            return $"{hours}h {minutes}m";
        }

    }
   
}
