﻿namespace Registrar.Models
{
    public class StudyRecord
    {
        public int Id { get; set; }
        public int SemesterModuleId { get; set; }
        public SemesterModule SemesterModule { get; set; }
        public DateTime Date { get; set; }
        public int Hours { get; set; }
        public int Minutes { get; set; }

    }
}
