﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Registrar.Data;
using Registrar.Models;

namespace Registrar.Controllers
{
    public class SemesterModulesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public SemesterModulesController(ApplicationDbContext context)
        {
            _context = context;
        }
        public async Task<IActionResult> Index()
        {
              return _context.modules != null ? 
                          View(await _context.modules.ToListAsync()) :
                          Problem("Entity set 'ApplicationDbContext.modules'  is null.");
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create( SemesterModule semesterModule)
        {
            if (ModelState.IsValid)
            {
                //Calculate SelfStudyHoursPerWeek
                semesterModule.SelfStudyHoursPerWeek = ((semesterModule.Credits * 10) / semesterModule.NumberofWeek) - semesterModule.ClassHoursPerWeek;
                _context.Add(semesterModule);
                await _context.SaveChangesAsync();

                var semesterModules = await _context.modules.FindAsync(semesterModule.Id);

                if (semesterModule != null)
                {
                    var studyRecord = new StudyRecord
                    {
                        SemesterModuleId = semesterModule.Id,
                        SemesterModule = semesterModule,
                        Date = DateTime.Now, // or the date when the study hours are recorded
                        Hours = semesterModule.SelfStudyHoursPerWeek
                    };
                    _context.StudyRecords.Add(studyRecord);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }                
            }
            return View(semesterModule);
        }
        public IActionResult Delete(int id)
        {
            if (_context.modules == null)
            {
                return Problem("Entity set 'ApplicationDbContext.modules'  is null.");
            }
            var semesterModule = _context.modules.Find(id);
            if (semesterModule != null)
            {
                _context.modules.Remove(semesterModule);
            }
            
             _context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        private bool SemesterModuleExists(int id)
        {
          return (_context.modules?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
