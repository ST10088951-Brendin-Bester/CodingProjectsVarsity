﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.Scripting;
using Microsoft.EntityFrameworkCore;
using Registrar.Data;
using Registrar.Models;
using System.Diagnostics;
using System.Security.Cryptography;

namespace Registrar.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;
        public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(Registeruser Login)
        {
            var user = _context.Registerusers.FirstOrDefault(u => u.Email == Login.Email);

            if (user != null)
            {
                // Validate the password
                bool isPasswordValid = ValidatePassword(Login.Password, user.Password);

                if (isPasswordValid)
                {
                    return RedirectToAction("Index", "SemesterModules");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Invalid email or password.");
                    return View(Login);
                }
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Invalid email or password.");
                return View(Login);
            }
        }

        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Register(Registeruser registeruser)
        {

            string passwordHash = HashPassword(registeruser.Password);

            var obj = new Registeruser
            {
                FirstName= registeruser.FirstName,
                LastName= registeruser.LastName,
                Email=registeruser.Email,
                Password= passwordHash,
            };
            try
            {
                _context.Registerusers.Add(obj);
                _context.SaveChanges();
                return RedirectToAction("Login");                    
            }
            catch (DbUpdateException ex)
            {
                var errorMessage = ex.Message;
                return View(registeruser);
            }
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        private string HashPassword(string password)
        {
            byte[] salt;
            new RNGCryptoServiceProvider().GetBytes(salt = new byte[16]);
            var pbkdf2 = new Rfc2898DeriveBytes(password, salt, 10000);
            byte[] hashedPassword = pbkdf2.GetBytes(20);
            byte[] passwordHash = new byte[36];
            Array.Copy(salt, 0, passwordHash, 0, 16);
            Array.Copy(hashedPassword, 0, passwordHash, 16, 20);
            string passwordHashString = Convert.ToBase64String(passwordHash);

            return passwordHashString;
        }
        private bool ValidatePassword(string enteredPassword, string storedPasswordHash)
        {
            byte[] passwordHash = Convert.FromBase64String(storedPasswordHash);
            byte[] salt = new byte[16];
            Array.Copy(passwordHash, 0, salt, 0, 16);
            using (var deriveBytes = new Rfc2898DeriveBytes(enteredPassword, salt, 10000))
            {
                byte[] enteredHashedPassword = deriveBytes.GetBytes(20);
                for (int i = 0; i < 20; i++)
                {
                    if (enteredHashedPassword[i] != passwordHash[i + 16])
                        return false;
                }
            }
            return true;
        }
    }
}