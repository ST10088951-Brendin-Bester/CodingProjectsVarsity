package com.zrax.miningmanagement.Employs;



import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;


import com.google.firebase.auth.FirebaseAuth;
import com.zrax.miningmanagement.databinding.ActivityEmployeeBinding;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class EmployeeActivity extends AppCompatActivity {
    ActivityEmployeeBinding binding;
    EmployeeAdepter adepter;
    String Node,JobTitleNode;
    ArrayList<EmployeeDataModel> model;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         binding = ActivityEmployeeBinding.inflate(getLayoutInflater());
         setContentView(binding.getRoot());








            Node = getIntent().getStringExtra("Node");
            JobTitleNode = getIntent().getStringExtra("JobTitleNode");
            model = new ArrayList<>();

            adepter = new EmployeeAdepter( model,EmployeeActivity.this,Node,JobTitleNode);

            binding.EmployeeDataRec.setLayoutManager(new LinearLayoutManager(this));
            binding.EmployeeDataRec.setAdapter(adepter);












            binding.floatingActionButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(EmployeeActivity.this, EmployeeDataAdd.class);
                    intent.putExtra("Node",Node);
                    intent.putExtra("JobTitleNode",JobTitleNode);
                    startActivity(intent);
                }
            });


            binding.HeadLine.setText(getIntent().getStringExtra("HeadLine"));


            AddData();


        }

        void AddData() {

            FirebaseDatabase.getInstance().getReference()
                    .child("Sites")
                    .child(FirebaseAuth.getInstance().getUid())
                    .child(Node).child("JobTitle")
                    .child(JobTitleNode).child("Employee")
                    .addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    model.clear();
                    if (snapshot.exists()) {
                        for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                            model.add(snapshot1.getValue(EmployeeDataModel.class));
                        }
                        adepter.notifyDataSetChanged();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });

        }




    }