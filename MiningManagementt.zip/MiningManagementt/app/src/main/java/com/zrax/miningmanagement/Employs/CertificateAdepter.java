package com.zrax.miningmanagement.Employs;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.zrax.miningmanagement.R;
import com.zrax.miningmanagement.databinding.IitemEmployeeBinding;
import com.zrax.miningmanagement.databinding.ItemCertificatesBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class CertificateAdepter extends RecyclerView.Adapter<CertificateAdepter.ViewHolder> {
    ArrayList<CertificatesModel> data; // Replace 'String' with your data type
    Context context;
    String Node,JobTitleNode,EmployeeNode;

    public CertificateAdepter(ArrayList<CertificatesModel> data, Context context, String node, String jobTitleNode, String employeeNode) {
        this.data = data;
        this.context = context;
        Node = node;
        JobTitleNode = jobTitleNode;
        EmployeeNode = employeeNode;
    }

    @NonNull
    @Override
    public CertificateAdepter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new CertificateAdepter.ViewHolder(LayoutInflater.from(context).inflate(R.layout.item_certificates,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull CertificateAdepter.ViewHolder holder, int position) {
        CertificatesModel DATA =  data.get(position);
        holder.binding.ExpireDate.setText(DATA.getExpiryDate());

        holder.binding.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, EmployeeDataAdd.class);
               //intent.putExtra("HeadLine",DATA.getName()+" Details Edit");
               //intent.putExtra("Name",DATA.getName());
               //intent.putExtra("Surname",DATA.getSurname());
               //intent.putExtra("Date",DATA.getDate());
               //intent.putExtra("ID",DATA.getId());
               //intent.putExtra("Node",Node);
               //intent.putExtra("JobTitleNode",JobTitleNode);
               //intent.putExtra("EmployeeNode",DATA.getEmployeeNode());

                context.startActivity(intent);
            }
        });
        holder.binding.see.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, EmployeeDetailsPage.class);
               //intent.putExtra("HeadLine",DATA.getName()+" Details Edit");
               //intent.putExtra("Name",DATA.getName());
               //intent.putExtra("Surname",DATA.getSurname());
               //intent.putExtra("Date",DATA.getDate());
               //intent.putExtra("ID",DATA.getId());
               //intent.putExtra("Node",Node);
               //intent.putExtra("JobTitleNode",JobTitleNode);
               // intent.putExtra("EmployeeNode",DATA.getEmployeeNode());
                context.startActivity(intent);
            }
        });
        holder.binding.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             showAlertDialog(DATA.getCertificateNode());


            }
        });

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ViewHolder extends  RecyclerView.ViewHolder {
   ItemCertificatesBinding binding;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            binding =  ItemCertificatesBinding.bind(itemView);
        }
    }

    public void showAlertDialog(String CertificateNode) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
        alertDialogBuilder.setTitle("Alert Title");
        alertDialogBuilder.setMessage("Are you sure you want to delete this?");

        alertDialogBuilder.setNegativeButton("CHANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Handle the "OK" button click here
                dialog.dismiss(); // Close the dialog
            }
        });
        alertDialogBuilder.setPositiveButton("DELETE", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                FirebaseDatabase.getInstance().getReference().child("Sites").child(FirebaseAuth.getInstance().getUid()).child(Node).child("JobTitle").child(JobTitleNode).child("Employee").child(EmployeeNode).child("Certificates").child(CertificateNode).setValue(null).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        notifyDataSetChanged();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(context, "Failed! Try again", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        // You can add more buttons with setNegativeButton, setNeutralButton, etc.

        // Create and show the AlertDialog
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

}
