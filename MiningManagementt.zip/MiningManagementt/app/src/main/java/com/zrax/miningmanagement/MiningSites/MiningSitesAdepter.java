package com.zrax.miningmanagement.MiningSites;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.zrax.miningmanagement.JobTitle.JobTitle;
import com.zrax.miningmanagement.R;
import com.zrax.miningmanagement.databinding.ItemMiningSitesBinding;

import java.util.ArrayList;

public class MiningSitesAdepter extends RecyclerView.Adapter<MiningSitesAdepter.ViewHolder> {
   ArrayList<MiningSitesModel> data; // Replace 'String' with your data type
  Context context;

    public MiningSitesAdepter(ArrayList<MiningSitesModel> data, Context context) {
        this.data = data;
        this.context = context;
    }


    @NonNull
    @Override
    public MiningSitesAdepter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.item_mining_sites,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MiningSitesAdepter.ViewHolder holder, int position) {
        MiningSitesModel DATA =  data.get(position);
        holder.binding.itemName.setText(DATA.getItemName());
        holder.binding.Open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, JobTitle.class);
                intent.putExtra("HeadLine","Mining "+DATA.getItemName());
                intent.putExtra("Node",DATA.getNode());
                context.startActivity(intent);
            }
        });
        holder.binding.Details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, SitesDetails.class);
                intent.putExtra("HeadLine",DATA.getItemName()+" Details Edit");
                intent.putExtra("ItemName",DATA.getItemName());
                intent.putExtra("Location",DATA.getLocation());
                intent.putExtra("Date",DATA.getDate());
                intent.putExtra("MineOwner",DATA.getMineOwner());
                intent.putExtra("Node",DATA.getNode());

                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ViewHolder extends  RecyclerView.ViewHolder {
        ItemMiningSitesBinding binding;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
             binding = ItemMiningSitesBinding.bind(itemView);
        }
    }
}
