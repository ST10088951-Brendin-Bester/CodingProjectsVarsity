package com.zrax.miningmanagement.Employs;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;


import com.zrax.miningmanagement.Certificates.CertificateAdepter;
import com.zrax.miningmanagement.Certificates.CertificatesModel;
import com.zrax.miningmanagement.databinding.ActivityEmployeeDetailsPageBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class EmployeeDetailsPage extends AppCompatActivity {
    ActivityEmployeeDetailsPageBinding binding;
    String Node, JobTitleNode, EmployeeNode;
    String Name, Surname, Date, Id, Headline;
    ArrayList<CertificatesModel> model;
    CertificateAdepter adepter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEmployeeDetailsPageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        Headline = getIntent().getStringExtra("HeadLine");
        Name = getIntent().getStringExtra("Name");
        Surname = getIntent().getStringExtra("Surname");
        Date = getIntent().getStringExtra("Date");
        Id = getIntent().getStringExtra("ID");
        Node = getIntent().getStringExtra("Node");
        JobTitleNode = getIntent().getStringExtra("JobTitleNode");
        EmployeeNode = getIntent().getStringExtra("EmployeeNode");


        binding.FullName.setText(Name + " " + Surname);
        binding.ID.setText(Id);
        binding.DateOfEmployment.setText(Date);

        JobTitleNode = getIntent().getStringExtra("JobTitleNode");
        model = new ArrayList<>();

        adepter = new CertificateAdepter(model, EmployeeDetailsPage.this, Node, JobTitleNode, EmployeeNode);

        binding.certificates.setLayoutManager(new LinearLayoutManager(this));
        binding.certificates.setAdapter(adepter);
        AddData();


        Toast.makeText(this, ""+ Node, Toast.LENGTH_SHORT).show();
        binding.floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EmployeeDetailsPage.this, CertificateAdd.class);
                intent.putExtra("Node", Node);
                intent.putExtra("JobTitleNode", JobTitleNode);
                intent.putExtra("EmployeeNode", EmployeeNode);

                startActivity(intent);
            }
        });
    }

    void AddData() {

        FirebaseDatabase.getInstance().getReference().child("Sites").child(FirebaseAuth.getInstance().getUid())
                .child(Node).child("JobTitle").child(JobTitleNode)
                .child("Employee").child(EmployeeNode)
                .child("Certificates")
                .addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                model.clear();
                if (snapshot.exists()) {
                    for (DataSnapshot snapshot1 : snapshot.getChildren()) {

                        FirebaseDatabase.getInstance().getReference()
                                .child("certificates")
                                .child(snapshot1.getValue(String.class))
                                .addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        if (snapshot.exists()){
                                            model.add(snapshot.getValue(CertificatesModel.class));
                                            adepter.notifyDataSetChanged();
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {

                                    }
                                });

                    }

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
}