package com.zrax.miningmanagement.Employs;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.Toast;

import com.zrax.miningmanagement.databinding.ActivityJobTitleAddBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Random;

public class EmployeeDataAdd extends AppCompatActivity {
    ActivityJobTitleAddBinding binding;
    String HeadLine ;
    String Node ;
    String JobTitleNode ;
    String Name;
    String Surname;
    String Date ;
    String ID;
    String EmployeeNode;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityJobTitleAddBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        HeadLine = getIntent().getStringExtra("HeadLine");
        Node = getIntent().getStringExtra("Node");
        JobTitleNode = getIntent().getStringExtra("JobTitleNode");
        EmployeeNode = getIntent().getStringExtra("EmployeeNode");
        Name = getIntent().getStringExtra("Name");
        Surname = getIntent().getStringExtra("Surname");
        Date = getIntent().getStringExtra("Date");
        ID = getIntent().getStringExtra("ID");

        if (EmployeeNode != null) {
            binding.JobTitleHeadLine.setText(HeadLine);
            binding.JobTitleName.setHint(Name);
            binding.JobTitleSurname.setHint(Surname);
            binding.JObTitleDate.setHint(Date);
            binding.JobTitleID.setHint(ID);
            binding.buttonText.setText("Update");
        }

        binding.saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                if (EmployeeNode != null) {
                    if (!binding.JobTitleName.getText().toString().isEmpty()){
                        Name= binding.JobTitleName.getText().toString();
                    }
                    if (!binding.JobTitleSurname.getText().toString().isEmpty()){
                        Surname = binding.JobTitleSurname.getText().toString();
                    }
                    if (!binding.JObTitleDate.getText().toString().isEmpty()){
                        Date = binding.JObTitleDate.getText().toString();
                        Toast.makeText(EmployeeDataAdd.this, ""+ Date, Toast.LENGTH_SHORT).show();
                    }
                    if (!binding.JobTitleID.getText().toString().isEmpty()){
                        ID = binding.JobTitleID.getText().toString();
                    }

                    DataEntryAndUpdate(Name, Surname, Date, ID,Node,JobTitleNode,EmployeeNode);
                } else {
                    if (!binding.JobTitleName.getText().toString().isEmpty() & !binding.JobTitleSurname.getText().toString().isEmpty() & !binding.JObTitleDate.getText().toString().isEmpty() & !binding.JobTitleID.getText().toString().isEmpty() ){
                        DataEntryAndUpdate(binding.JobTitleName.getText().toString(),binding.JobTitleSurname.getText().toString(), binding.JObTitleDate.getText().toString(),binding.JobTitleID.getText().toString(),Node,JobTitleNode,generateRandomString());
                    }
                    else {
                    }
                }
            }
        });


        binding.SitesEntryDatePiker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDatePickerDialog();
            }
        });
    }

    private void openDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int selectedYear, int selectedMonth, int selectedDay) {
                        // Handle the selected date
                        String selectedDate = selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear;
                        binding.JObTitleDate.setText(selectedDate);
                    }
                },
                year, month, day
        );

        datePickerDialog.show();
    }

    @Override
    public void onBackPressed() {
        finish();
        super.onBackPressed();


    }

    void DataEntryAndUpdate(String name, String surname, String date, String id, String node,String JobTitleNode,String EmployeeNode) {

        HashMap<String, String> map = new HashMap<>();
        map.put("Name", name);
        map.put("Surname", surname);
        map.put("Date", date);
        map.put("Id", id);
        map.put("EmployeeNode", EmployeeNode);
        FirebaseDatabase.getInstance().getReference().child("Sites").child(FirebaseAuth.getInstance().getUid()).child(node).child("JobTitle").child(JobTitleNode).child("Employee").child(EmployeeNode).setValue(map)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        finish();

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(EmployeeDataAdd.this, "Failed! Try Again", Toast.LENGTH_SHORT).show();
                    }
                });
    }


    public static String generateRandomString() {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder randomString = new StringBuilder(10);
        Random random = new Random();

        for (int i = 0; i < 10; i++) {
            int randomIndex = random.nextInt(characters.length());
            char randomChar = characters.charAt(randomIndex);
            randomString.append(randomChar);
        }

        return randomString.toString();
    }
}