package com.zrax.miningmanagement.Employs;

import static com.zrax.miningmanagement.Certificates.CertificateEdit.convertDateToTimestamp;
import static com.zrax.miningmanagement.Employs.EmployeeDataAdd.generateRandomString;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.Toast;


import com.zrax.miningmanagement.databinding.ActivityCertificateAddBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

public class CertificateAdd extends AppCompatActivity {
    private static final int PICK_IMAGE_REQUEST = 1;
    String  CCertificateImage;
    Uri selectedImageUri;

    ActivityCertificateAddBinding binding;
    String Node, JobTitleNode, EmployeeNode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCertificateAddBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        Node = getIntent().getStringExtra("Node");
        JobTitleNode = getIntent().getStringExtra("JobTitleNode");
        EmployeeNode = getIntent().getStringExtra("EmployeeNode");

        binding.DatePiker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDatePickerDialog();
            }
        });
        binding.saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!binding.CertificateName.getText().toString().isEmpty() & !binding.ExpiryDate.getText().toString().isEmpty() & !getCCertificateImage().isEmpty()) {
                    UploadImage(generateRandomString());
                } else {
                    Toast.makeText(CertificateAdd.this, "Fill All Details", Toast.LENGTH_SHORT).show();
                }
            }
        });
        binding.pickImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkPermission()) {
                    pickImageFromGallery();
                }
            }
        });
    }


    private void pickImageFromGallery() {

        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE_REQUEST);

        // Handle the case where the user didn't grant permission.
        // You can display a message or request permission again.

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK) {
            // Handle the selected image
            selectedImageUri = data.getData();
            binding.CertificateAddOn.setImageURI(selectedImageUri);
            setCCertificateImage(String.valueOf(selectedImageUri));
            // Now, you can use the selectedImageUri to display or process the image.
        }
    }




    public String getCCertificateImage() {
        return CCertificateImage;
    }

    public void setCCertificateImage(String CCertificateImage) {
        this.CCertificateImage = CCertificateImage;
    }

    public static boolean PermissionCheck(Context context) {
        final boolean[] permission = {false};
        Dexter.withContext(context)
                .withPermissions(
                        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                ).withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        if (report.areAllPermissionsGranted()) {
                            permission[0] = true;
                        }

                    }

                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).check();

        return permission[0];

    }


    @RequiresApi(api = Build.VERSION_CODES.TIRAMISU)
    public static boolean PermissionCheckForAndroid13(Context context) {
        int permissionSendMessage = ContextCompat.checkSelfPermission(context,
                android.Manifest.permission.READ_MEDIA_IMAGES);
        int locationPermission = ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_MEDIA_VIDEO);


        List<String> listPermissionsNeeded = new ArrayList<>();


        if (locationPermission != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(android.Manifest.permission.READ_MEDIA_VIDEO);
        }
        if (permissionSendMessage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(android.Manifest.permission.READ_MEDIA_IMAGES);
        }

        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions((Activity) context, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), 1);
            return false;
        }
        return true;
    }


    @SuppressLint("ObsoleteSdkInt")
    public boolean checkPermission() {

        if (Build.VERSION.SDK_INT >= 33) {
            if (PermissionCheckForAndroid13(CertificateAdd.this)) {
                return true;
            } else {
                return false;
            }
        } else {
            if (PermissionCheck(CertificateAdd.this)) {
                return true;
            } else {
                return false;
            }
        }
    }

    void UploadImage(String CertificateName) {
        StorageReference storageRef = FirebaseStorage.getInstance().getReference().child("images");
        final StorageReference imageRef = storageRef.child(selectedImageUri.getLastPathSegment());

        imageRef.putFile(selectedImageUri).addOnSuccessListener(taskSnapshot -> {
            // Image uploaded successfully, now get the download URL
            imageRef.getDownloadUrl().addOnSuccessListener(uri -> {
                String imageUrl = uri.toString();
                DataEntry(imageUrl);
                Toast.makeText(this, "Profile pic updated!", Toast.LENGTH_SHORT).show();
            });
        }).addOnFailureListener(e -> {
            // Handle the error
        });
    }

    void DataEntry(String CertificateUrl) {

        DatabaseReference ref =  FirebaseDatabase.getInstance().getReference().child("Sites").child(FirebaseAuth.getInstance().getUid())
                .child(Node).child("JobTitle").child(JobTitleNode)
                .child("Employee").child(EmployeeNode);




        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    String name = snapshot.child("Name").getValue(String.class)
                            + " " + snapshot.child("Surname").getValue(String.class);

                    Toast.makeText(CertificateAdd.this, "DataEntry", Toast.LENGTH_SHORT).show();
                    String CertificateNode = generateRandomString();
                    HashMap<String, String> map = new HashMap<>();
                    map.put("CertificateName", binding.CertificateName.getText().toString());
                    map.put("ExpiryDate", binding.ExpiryDate.getText().toString());
                    map.put("CertificateUrl", CertificateUrl);
                    map.put("CertificateNode", CertificateNode);
                    map.put("name", name);
                    map.put("timestamp", String.valueOf(convertDateToTimestamp(binding.ExpiryDate.getText().toString())));


                    ref.child("Certificates")
                            .push()
                            .setValue(CertificateNode)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    finish();

                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(CertificateAdd.this, "Failed! Try Again", Toast.LENGTH_SHORT).show();
                                }
                            });

                    FirebaseDatabase.getInstance().getReference().child("certificates")
                            .child(CertificateNode)
                            .setValue(map);





                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }

    private void openDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int selectedYear, int selectedMonth, int selectedDay) {
                        // Handle the selected date
                        String selectedDate = selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear;
                        binding.ExpiryDate.setText(selectedDate);
                    }
                },
                year, month, day
        );

        datePickerDialog.show();
    }


}