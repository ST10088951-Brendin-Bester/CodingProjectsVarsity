package com.zrax.miningmanagement.certificatesList;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.zrax.miningmanagement.R;
import com.zrax.miningmanagement.databinding.ItemCertificatesBinding;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;

import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;

public class CertificateAdepter extends RecyclerView.Adapter<CertificateAdepter.ViewHolder> {
    ArrayList<CertificatesModel> data; // Replace 'String' with your data type
    Context context;
    String Node,JobTitleNode,EmployeeNode;

    public CertificateAdepter(ArrayList<CertificatesModel> data, Context context) {
        this.data = data;
        this.context = context;

    }

    @NonNull
    @Override
    public CertificateAdepter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new CertificateAdepter.ViewHolder(LayoutInflater.from(context).inflate(R.layout.item_certificates,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull CertificateAdepter.ViewHolder holder, int position) {
        CertificatesModel DATA =  data.get(position);
        holder.binding.ExpireDate.setText(DATA.getExpiryDate());

        Glide.with(context).load(DATA.getCertificateUrl()).into(holder.binding.Certi);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            holder.binding.textView2.setText(""+calculateTimeDifference(new Date().getTime(), Long.parseLong(DATA.getTimestamp())));

        }


        holder.binding.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, CertificateEdit.class);

                intent.putExtra("Node",Node);
                intent.putExtra("JobTitleNode",JobTitleNode);
                intent.putExtra("EmployeeNode",EmployeeNode);
                intent.putExtra("CertificateNode", DATA.getCertificateNode());
                intent.putExtra("CertificateName",DATA.getCertificateName());
                intent.putExtra("CertificateUrl",DATA.getCertificateUrl());
                intent.putExtra("ExpiryDate",DATA.getExpiryDate());
                context.startActivity(intent);


            }
        });
        holder.binding.see.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, show.class);


               intent.putExtra("CertificateName",DATA.getCertificateName());
               intent.putExtra("ExpiryDate",DATA.getExpiryDate());
               intent.putExtra("name",DATA.getName());
               intent.putExtra("CertificateImageUrl",DATA.getCertificateUrl());

                context.startActivity(intent);
            }
        });
        holder.binding.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             showAlertDialog(DATA.getCertificateNode());


            }
        });

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ViewHolder extends  RecyclerView.ViewHolder {
   ItemCertificatesBinding binding;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            binding =  ItemCertificatesBinding.bind(itemView);
        }
    }

    public void showAlertDialog(String CertificateNode) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
        alertDialogBuilder.setTitle("Alert Title");
        alertDialogBuilder.setMessage("Are you sure you want to delete this?");

        alertDialogBuilder.setNegativeButton("CHANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Handle the "OK" button click here
                dialog.dismiss(); // Close the dialog
            }
        });
        alertDialogBuilder.setPositiveButton("DELETE", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                FirebaseDatabase.getInstance().getReference()
                        .child("certificates")
                        .child(CertificateNode)
                        .setValue(null).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        notifyDataSetChanged();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(context, "Failed! Try again", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        // You can add more buttons with setNegativeButton, setNeutralButton, etc.

        // Create and show the AlertDialog
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    public static String calculateTimeDifference(long timestamp1, long timestamp2) {
        Instant instant1 = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            instant1 = Instant.ofEpochMilli(timestamp1);
        }
        Instant instant2 = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            instant2 = Instant.ofEpochMilli(timestamp2);
        }

        LocalDate date1 = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            date1 = instant1.atZone(ZoneId.systemDefault()).toLocalDate();
        }
        LocalDate date2 = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            date2 = instant2.atZone(ZoneId.systemDefault()).toLocalDate();
        }

        Period period = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            period = Period.between(date1, date2);
        }

        int months = 0;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            months = period.getMonths();
        }
        int days = 0;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            days = period.getDays();
        }

        StringBuilder result = new StringBuilder();

        if (months > 0) {
            result.append(months);
            result.append(" month");
            if (months > 1) {
                result.append("s");
            }
            if (days > 0) {
                result.append(" and ");
            }
        }

        if (days > 0) {
            result.append(days);
            result.append(" day");
            if (days > 1) {
                result.append("s");
            }
        }

        result.append(" remaining");

        return result.toString();
    }

}
