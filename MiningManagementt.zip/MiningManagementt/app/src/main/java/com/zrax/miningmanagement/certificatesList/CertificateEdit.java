package com.zrax.miningmanagement.certificatesList;

import static com.zrax.miningmanagement.Certificates.CertificateEdit.convertDateToTimestamp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.Toast;

import com.zrax.miningmanagement.R;
import com.zrax.miningmanagement.databinding.ActivityCertificateEditBinding;
import com.zrax.miningmanagement.databinding.ActivityEmployeeBinding;
import com.zrax.miningmanagement.databinding.ActivitySitesDataEntryBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.HashMap;

public class CertificateEdit extends AppCompatActivity {
    ActivityCertificateEditBinding binding;
    String Node,JobTitleNode,EmployeeNode,CertificateNode ;

    String CertificateName,CertificateUrl;

    String ExpiryDate ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCertificateEditBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        Node = getIntent().getStringExtra("Node");
        JobTitleNode = getIntent().getStringExtra("JobTitleNode");
        EmployeeNode = getIntent().getStringExtra("EmployeeNode");
        CertificateNode = getIntent().getStringExtra("CertificateNode");
        CertificateName = getIntent().getStringExtra("CertificateName");
        CertificateUrl = getIntent().getStringExtra("CertificateUrl");
        ExpiryDate = getIntent().getStringExtra("ExpiryDate");


        if (CertificateNode != null) {

            binding.CertificateName.setHint(getIntent().getStringExtra("CertificateName"));
            binding.CertificateExpiryDate.setHint(getIntent().getStringExtra("ExpiryDate"));
            binding.buttonText.setText("Update");
        }

        binding.saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                if (CertificateNode != null) {
                    if (!binding.CertificateName.getText().toString().isEmpty()){
                        CertificateName= binding.CertificateName.getText().toString();
                    }
                    if (!binding.CertificateExpiryDate.getText().toString().isEmpty()){
                        ExpiryDate = binding.CertificateExpiryDate.getText().toString();
                    }


                    DataUpdate(CertificateName,ExpiryDate,CertificateUrl,Node,JobTitleNode,EmployeeNode,CertificateNode);

                }
            }
        });


        binding.SitesEntryDatePiker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDatePickerDialog();
            }
        });
    }

    private void openDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int selectedYear, int selectedMonth, int selectedDay) {
                        // Handle the selected date
                        String selectedDate = selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear;
                        binding.CertificateExpiryDate.setText(selectedDate);
                    }
                },
                year, month, day
        );

        datePickerDialog.show();
    }

    @Override
    public void onBackPressed() {
        finish();
        super.onBackPressed();


    }

    void DataUpdate(String CertificateName, String ExpiryDate, String CertificateUrl, String node, String jobTitleNode, String employeeNode, String certificateNode) {

        DatabaseReference ref =  FirebaseDatabase.getInstance().getReference()
                .child("certificates")
                .child(CertificateNode);


        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    HashMap<String, String> map = new HashMap<>();

                    map.put("CertificateName", CertificateName);
                    map.put("ExpiryDate", ExpiryDate);
                    map.put("CertificateUrl", CertificateUrl);
                    map.put("CertificateNode", certificateNode);
                    map.put("name", snapshot.child("name").getValue(String.class));
                    map.put("timestamp", String.valueOf(convertDateToTimestamp(ExpiryDate)));


                    ref.setValue(map)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    finish();

                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(CertificateEdit.this, "Failed! Try Again", Toast.LENGTH_SHORT).show();
                                }
                            });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }



}