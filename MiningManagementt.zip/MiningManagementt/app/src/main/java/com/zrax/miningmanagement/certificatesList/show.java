package com.zrax.miningmanagement.certificatesList;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.zrax.miningmanagement.R;
import com.zrax.miningmanagement.databinding.ActivityCertificateDetailsPageBinding;
import com.zrax.miningmanagement.databinding.ShowCertificateListBinding;
import com.bumptech.glide.Glide;

public class show extends AppCompatActivity {
    ShowCertificateListBinding binding;
    String CertificateName,ExpiryDate,CertificateImageUrl;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ShowCertificateListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());



        CertificateName = getIntent().getStringExtra("CertificateName");
        ExpiryDate = getIntent().getStringExtra("ExpiryDate");
        CertificateImageUrl = getIntent().getStringExtra("CertificateImageUrl");



        binding.CertificateName.setText(CertificateName);
        binding.CertificateExpiryDate.setText(ExpiryDate);
        binding.employeeNamee.setText(getIntent().getStringExtra("name"));
        Glide.with(this).load(CertificateImageUrl).into(binding.CertificateImage);


    }
}