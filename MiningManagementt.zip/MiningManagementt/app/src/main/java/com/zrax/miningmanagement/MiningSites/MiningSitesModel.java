package com.zrax.miningmanagement.MiningSites;

public class MiningSitesModel {
    String ItemName,Location,Date,MineOwner,Node;

    public MiningSitesModel(String itemName, String location, String date, String mineOwner, String node) {
        ItemName = itemName;
        Location = location;
        Date = date;
        MineOwner = mineOwner;
        Node = node;
    }

    public MiningSitesModel() {
    }



    public String getItemName() {
        return ItemName;
    }

    public void setItemName(String itemName) {
        ItemName = itemName;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getMineOwner() {
        return MineOwner;
    }

    public void setMineOwner(String mineOwner) {
        MineOwner = mineOwner;
    }

    public String getNode() {
        return Node;
    }

    public void setNode(String node) {
        Node = node;
    }
}
