package com.zrax.miningmanagement.JobTitle;


import static com.zrax.miningmanagement.Employs.EmployeeDataAdd.generateRandomString;
import static com.zrax.miningmanagement.JobTitle.JobTitleDialog.showJobTitleDialog;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.zrax.miningmanagement.databinding.ActivityJonbTitleBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

public class JobTitle extends AppCompatActivity {
    ActivityJonbTitleBinding binding;
    String Node;

    JobTitlesAdepter adepter;
    ArrayList<JobTitlesModel> model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityJonbTitleBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        Node = getIntent().getStringExtra("Node");
        model = new ArrayList<>();

        adepter = new JobTitlesAdepter( JobTitle.this,model,getIntent().getStringExtra("Node"));

        binding.JobTitleRecy.setLayoutManager(new LinearLayoutManager(this));
        binding.JobTitleRecy.setAdapter(adepter);

        //binding.floatingActionButton.setOnClickListener(new View.OnClickListener() {
        //    @Override
        //    public void onClick(View view) {
        //        Intent intent = new Intent(JobTitle.this, JobTitleAdd.class);
        //        intent.putExtra("Node",Node);
        //        startActivity(intent);
        //    }
        //});

        binding.floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showJobTitleDialog(JobTitle.this, new JobTitleDialog.JobTitleDialogListener() {
                    @Override
                    public void onJobTitleEntered(String jobTitle) {
                        AddJobTitle(Node, jobTitle, generateRandomString());
                    }
                });
            }
        });
        binding.HeadLine.setText(getIntent().getStringExtra("HeadLine"));


        AddData();


    }

    void AddData() {

        FirebaseDatabase.getInstance().getReference().child("Sites").child(FirebaseAuth.getInstance().getUid()).child(Node).child("JobTitle").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                model.clear();
                if (snapshot.exists()) {
                    for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                        JobTitlesModel modell = snapshot1.getValue(JobTitlesModel.class);
                        modell.setRef(snapshot1.child("JobTitle").getRef());
                        model.add(modell);

                    }
                    adepter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    public void AddJobTitle(String Node, String JobTitle, String JobTitleNode) {
        HashMap<String, String> map = new HashMap<>();
        map.put("JobTitle", JobTitle);
        map.put("JobTitleNode", JobTitleNode);
        FirebaseDatabase.getInstance().getReference().child("Sites").child(FirebaseAuth.getInstance().getUid()).child(Node).child("JobTitle").child(JobTitleNode).setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {


            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(JobTitle.this, "Failed! Try Again", Toast.LENGTH_SHORT).show();
            }
        });
    }


}