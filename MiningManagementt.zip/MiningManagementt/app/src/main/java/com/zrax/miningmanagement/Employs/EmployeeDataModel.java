package com.zrax.miningmanagement.Employs;

public class EmployeeDataModel {
    String Name,Surname,Date,Id,EmployeeNode;

    public EmployeeDataModel(String name, String surname, String date, String id, String employeeNode) {
        Name = name;
        Surname = surname;
        Date = date;
        Id = id;
        EmployeeNode = employeeNode;
    }

    public EmployeeDataModel() {
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getSurname() {
        return Surname;
    }

    public void setSurname(String surname) {
        Surname = surname;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getEmployeeNode() {
        return EmployeeNode;
    }

    public void setEmployeeNode(String employeeNode) {
        EmployeeNode = employeeNode;
    }
}
