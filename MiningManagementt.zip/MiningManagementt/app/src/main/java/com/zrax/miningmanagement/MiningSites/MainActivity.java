package com.zrax.miningmanagement.MiningSites;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.zrax.miningmanagement.Splesh;
import com.zrax.miningmanagement.certificatesList.CertificateDetailsPage;
import com.zrax.miningmanagement.databinding.ActivityMainBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding binding;
    MiningSitesAdepter adepter;
    ArrayList<MiningSitesModel> model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        model = new ArrayList<>();

        adepter = new MiningSitesAdepter(model, MainActivity.this);

        binding.MiningSitesRecy.setLayoutManager(new LinearLayoutManager(this));
        binding.MiningSitesRecy.setAdapter(adepter);

        binding.floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SitesDataEntry.class);

                startActivity(intent);
            }
        });

        binding.certificateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, CertificateDetailsPage.class);

                startActivity(intent);
            }
        });


        AddData();


    }

    void AddData() {

        FirebaseDatabase.getInstance().getReference().child("Sites").child(FirebaseAuth.getInstance().getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                model.clear();
                if (snapshot.exists()){
                    for (DataSnapshot snapshot1 : snapshot.getChildren()){
                        model.add(snapshot1.getValue(MiningSitesModel.class));
                    }
                    adepter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        binding.logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                // Redirect to the login or home screen, or any desired destination
                startActivity(new Intent(MainActivity.this, Splesh.class));
                finish();

            }
        });

    }
}