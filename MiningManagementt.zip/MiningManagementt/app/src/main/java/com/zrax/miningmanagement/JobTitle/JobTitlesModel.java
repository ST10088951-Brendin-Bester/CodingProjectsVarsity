package com.zrax.miningmanagement.JobTitle;

import com.google.firebase.database.DatabaseReference;

public class JobTitlesModel {

    String JobTitle,JobTitleNode;
    DatabaseReference ref;

    public DatabaseReference getRef() {
        return ref;
    }

    public void setRef(DatabaseReference ref) {
        this.ref = ref;
    }

    public JobTitlesModel() {
    }

    public JobTitlesModel(String jobTitle, String jobTitleNode) {
        JobTitle = jobTitle;
        JobTitleNode = jobTitleNode;
    }

    public String getJobTitle() {
        return JobTitle;
    }

    public void setJobTitle(String jobTitle) {
        JobTitle = jobTitle;
    }

    public String getJobTitleNode() {
        return JobTitleNode;
    }

    public void setJobTitleNode(String jobTitleNode) {
        JobTitleNode = jobTitleNode;
    }
}
