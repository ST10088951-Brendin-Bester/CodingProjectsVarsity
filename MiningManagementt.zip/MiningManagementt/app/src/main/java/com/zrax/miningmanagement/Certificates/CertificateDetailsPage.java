package com.zrax.miningmanagement.Certificates;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.zrax.miningmanagement.R;
import com.zrax.miningmanagement.databinding.ActivityCertificateDetailsPageBinding;
import com.zrax.miningmanagement.databinding.ActivityEmployeeDetailsPageBinding;
import com.bumptech.glide.Glide;

public class CertificateDetailsPage extends AppCompatActivity {
ActivityCertificateDetailsPageBinding binding;

    String CertificateName,ExpiryDate,CertificateImageUrl;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCertificateDetailsPageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());



        CertificateName = getIntent().getStringExtra("CertificateName");
        ExpiryDate = getIntent().getStringExtra("ExpiryDate");
        CertificateImageUrl = getIntent().getStringExtra("CertificateImageUrl");



        binding.CertificateName.setText(CertificateName);
        binding.CertificateExpiryDate.setText(ExpiryDate);
        Glide.with(this).load(CertificateImageUrl).into(binding.CertificateImage);






    }


}