package com.zrax.miningmanagement.MiningSites;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.Toast;

import com.zrax.miningmanagement.databinding.ActivitySitesDataEntryBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Random;

public class SitesDataEntry extends AppCompatActivity {
    ActivitySitesDataEntryBinding binding;
    String HeadLine ;
    String Node ;
    String ItemName;
    String Location;
    String Date ;
    String MineOwner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySitesDataEntryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        HeadLine = getIntent().getStringExtra("HeadLine");
        Node = getIntent().getStringExtra("Node");
        ItemName = getIntent().getStringExtra("ItemName");
        Location = getIntent().getStringExtra("Location");
        Date = getIntent().getStringExtra("Date");
        MineOwner = getIntent().getStringExtra("MineOwner");

        if (HeadLine != null) {
            binding.HeadLine.setText(HeadLine);
            binding.SitesEntryName.setHint(getIntent().getStringExtra("ItemName"));
            binding.SitesEntryLocation.setHint(getIntent().getStringExtra("Location"));
            binding.SitesEntryStartDate.setHint(getIntent().getStringExtra("Date"));
            binding.SitesEntryMineOwner.setHint(getIntent().getStringExtra("MineOwner"));
            binding.buttonText.setText("Update");
        }

        binding.saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                if (Node != null) {
                    if (!binding.SitesEntryName.getText().toString().isEmpty()){
                        ItemName= binding.SitesEntryName.getText().toString();
                    }
                    if (!binding.SitesEntryLocation.getText().toString().isEmpty()){
                       Location = binding.SitesEntryLocation.getText().toString();
                    }
                    if (!binding.SitesEntryStartDate.getText().toString().isEmpty()){
                        Date = binding.SitesEntryStartDate.getText().toString();
                    }
                    if (!binding.SitesEntryMineOwner.getText().toString().isEmpty()){
                        MineOwner = binding.SitesEntryMineOwner.getText().toString();
                    }

                    DataEntryAndUpdate(ItemName, Location, Date, MineOwner,Node);
                } else {
                    if (!binding.SitesEntryName.getText().toString().isEmpty() & !binding.SitesEntryLocation.getText().toString().isEmpty() & !binding.SitesEntryStartDate.getText().toString().isEmpty() & !binding.SitesEntryMineOwner.getText().toString().isEmpty() ){
                    DataEntryAndUpdate(binding.SitesEntryName.getText().toString(),binding.SitesEntryLocation.getText().toString(), binding.SitesEntryStartDate.getText().toString(),binding.SitesEntryMineOwner.getText().toString(),generateRandomString());
                    }
                    else {
                    }
                }
            }
        });


        binding.SitesEntryDatePiker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDatePickerDialog();
            }
        });
    }

    private void openDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int selectedYear, int selectedMonth, int selectedDay) {
                        // Handle the selected date
                        String selectedDate = selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear;
                        binding.SitesEntryStartDate.setText(selectedDate);
                    }
                },
                year, month, day
        );

        datePickerDialog.show();
    }

    @Override
    public void onBackPressed() {
        finish();
        super.onBackPressed();


    }

    void DataEntryAndUpdate(String itemName, String location, String date, String mineOwner, String node) {

        HashMap<String, String> map = new HashMap<>();
        map.put("ItemName", itemName);
        map.put("Location", location);
        map.put("Date", date);
        map.put("MineOwner", mineOwner);
        map.put("Node", node);
        FirebaseDatabase.getInstance().getReference().child("Sites").child(FirebaseAuth.getInstance().getUid()).child(node).setValue(map)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        finish();

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(SitesDataEntry.this, "Failed! Try Again", Toast.LENGTH_SHORT).show();
                    }
                });
    }


    public static String generateRandomString() {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder randomString = new StringBuilder(10);
        Random random = new Random();

        for (int i = 0; i < 10; i++) {
            int randomIndex = random.nextInt(characters.length());
            char randomChar = characters.charAt(randomIndex);
            randomString.append(randomChar);
        }

        return randomString.toString();
    }
}