package com.zrax.miningmanagement.Employs;

public class CertificatesModel {

    String CertificateName,ExpiryDate,CertificateUrl,CertificateNode;

    public CertificatesModel(String certificateName, String expiryDate, String certificateUrl, String certificateNode) {
        CertificateName = certificateName;
        ExpiryDate = expiryDate;
        CertificateUrl = certificateUrl;
        CertificateNode = certificateNode;
    }

    public CertificatesModel() {
    }

    public String getCertificateNode() {
        return CertificateNode;
    }

    public void setCertificateNode(String certificateNode) {
        CertificateNode = certificateNode;
    }

    public String getCertificateName() {
        return CertificateName;
    }

    public void setCertificateName(String certificateName) {
        CertificateName = certificateName;
    }

    public String getExpiryDate() {
        return ExpiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        ExpiryDate = expiryDate;
    }

    public String getCertificateUrl() {
        return CertificateUrl;
    }

    public void setCertificateUrl(String certificateUrl) {
        CertificateUrl = certificateUrl;
    }
}
