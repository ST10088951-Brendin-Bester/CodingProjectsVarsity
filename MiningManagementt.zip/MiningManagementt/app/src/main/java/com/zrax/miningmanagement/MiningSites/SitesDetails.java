package com.zrax.miningmanagement.MiningSites;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.zrax.miningmanagement.databinding.ActivitySitesDetailsBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class SitesDetails extends AppCompatActivity {
    ActivitySitesDetailsBinding binding;
    String HeadLine;
    String Node;
    String ItemName;
    String Location;
    String Date;
    String MineOwner;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySitesDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        HeadLine = getIntent().getStringExtra("HeadLine");
        Node = getIntent().getStringExtra("Node");
        ItemName = getIntent().getStringExtra("ItemName");
        Location = getIntent().getStringExtra("Location");
        Date = getIntent().getStringExtra("Date");
        MineOwner = getIntent().getStringExtra("MineOwner");

        binding.HeadLine.setText(HeadLine);
        binding.DetailsItemName.setText(ItemName);
        binding.DetailsLocation.setText(Location);
        binding.DetailsDtae.setText(Date);
        binding.DetailsMineOwner.setText(MineOwner);


        binding.DetailsItemEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SitesDetails.this, SitesDataEntry.class);
                intent.putExtra("HeadLine", HeadLine);
                intent.putExtra("ItemName", ItemName);
                intent.putExtra("Location", Location);
                intent.putExtra("Date", Date);
                intent.putExtra("MineOwner", MineOwner);
                intent.putExtra("Node", Node);
                startActivity(intent);
            }
        });

        binding.DetailsItemDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAlertDialog();
            }
        });
    }

    public void showAlertDialog() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(SitesDetails.this);
        alertDialogBuilder.setTitle("Alert Title");
        alertDialogBuilder.setMessage("Are you sure you want to delete this?");

        alertDialogBuilder.setNegativeButton("CHANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Handle the "OK" button click here
                dialog.dismiss(); // Close the dialog
            }
        });
        alertDialogBuilder.setPositiveButton("DELETE", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                FirebaseDatabase.getInstance().getReference().child("Sites").child(FirebaseAuth.getInstance().getUid()).child(Node).setValue(null)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                finish();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(SitesDetails.this, "Task Is not Completed !", Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });

        // You can add more buttons with setNegativeButton, setNeutralButton, etc.

        // Create and show the AlertDialog
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }
}