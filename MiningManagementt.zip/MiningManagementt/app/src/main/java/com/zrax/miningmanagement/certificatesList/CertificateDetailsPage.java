package com.zrax.miningmanagement.certificatesList;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Bundle;

import com.zrax.miningmanagement.R;
import com.zrax.miningmanagement.databinding.ActivityCertificateDetailsPageBinding;
import com.zrax.miningmanagement.databinding.ActivityEmployeeDetailsPageBinding;
import com.zrax.miningmanagement.databinding.CertificatesListBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class CertificateDetailsPage extends AppCompatActivity {
CertificatesListBinding binding;

    String CertificateName,ExpiryDate,CertificateImageUrl;

    ArrayList<CertificatesModel> model;
    CertificateAdepter adepter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = CertificatesListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        model = new ArrayList<>();

        adepter = new CertificateAdepter(model, CertificateDetailsPage.this);

        binding.rec.setLayoutManager(new LinearLayoutManager(this));
        binding.rec.setAdapter(adepter);
        AddData();



    }

    void AddData() {

        FirebaseDatabase.getInstance().getReference().child("certificates")
                .orderByChild("timestamp").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                model.clear();
                if (snapshot.exists()){
                    for (DataSnapshot snapshot1 : snapshot.getChildren()){
                        model.add(snapshot1.getValue(CertificatesModel.class));
                    }
                    adepter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
}