package com.zrax.miningmanagement;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.google.firebase.auth.FirebaseAuth;
import com.zrax.miningmanagement.Login.LoginActivity;
import com.zrax.miningmanagement.MiningSites.MainActivity;
import com.zrax.miningmanagement.databinding.ActivitySpleshBinding;

public class Splesh extends AppCompatActivity {
    ActivitySpleshBinding binding;

    private static final int SPLASH_DURATION = 2000; // Adjust the duration as needed

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         binding = ActivitySpleshBinding.inflate(getLayoutInflater());
         setContentView(binding.getRoot());







        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {



                    // User is already authenticated, show the main content or dashboard

                if (FirebaseAuth.getInstance().getCurrentUser() != null){
                    Intent intent = new Intent(Splesh.this, MainActivity.class);
                    startActivity(intent);
                    finish(); // Optional: Close the current activity to prevent the user from going back to the login screen


                }
                else{
                    Intent intent = new Intent(Splesh.this, LoginActivity.class);
                    startActivity(intent);
                    finish(); // Optional: Close the current activity to prevent the user from going back to the login screen
                }

            }
        }, SPLASH_DURATION);
    }
}
