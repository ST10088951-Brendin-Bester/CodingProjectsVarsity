package com.zrax.miningmanagement.JobTitle;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.zrax.miningmanagement.R;

public class JobTitleDialog {

    public static void showJobTitleDialog(Context context, final JobTitleDialogListener listener) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
        alertDialogBuilder.setTitle("Enter Job Title");

        LayoutInflater inflater = LayoutInflater.from(context);
        View dialogView = inflater.inflate(R.layout.job_title_entry, null);

        final EditText jobTitleEditText = dialogView.findViewById(R.id.jobTitleEditText);
        Button addButton = dialogView.findViewById(R.id.addButton);

        alertDialogBuilder.setView(dialogView);

        final AlertDialog alertDialog = alertDialogBuilder.create();

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String jobTitle = jobTitleEditText.getText().toString();
                if (!jobTitle.isEmpty()) {
                    listener.onJobTitleEntered(jobTitle);
                    alertDialog.dismiss();
                } else {
                    // Show an error message or handle the case where the input is empty
                }
            }
        });

        alertDialogBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        // Show the AlertDialog
        alertDialog.show();
    }

    public interface JobTitleDialogListener {
        void onJobTitleEntered(String jobTitle);
    }
}
