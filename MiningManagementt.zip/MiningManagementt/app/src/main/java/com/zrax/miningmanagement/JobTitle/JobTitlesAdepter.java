package com.zrax.miningmanagement.JobTitle;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.zrax.miningmanagement.Employs.EmployeeActivity;
import com.zrax.miningmanagement.R;
import com.zrax.miningmanagement.databinding.ItemMiningSitesBinding;

import java.util.ArrayList;

public class JobTitlesAdepter extends RecyclerView.Adapter<JobTitlesAdepter.viewHolder> {
    Context context;
    ArrayList<JobTitlesModel> data;
    String Node;

    public JobTitlesAdepter(Context context, ArrayList<JobTitlesModel> data, String node) {
        this.context = context;
        this.data = data;
        Node = node;
    }

    @NonNull
    @Override
    public JobTitlesAdepter.viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new viewHolder(LayoutInflater.from(context).inflate(R.layout.item_mining_sites, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull JobTitlesAdepter.viewHolder holder, int position) {

        JobTitlesModel Data = data.get(position);
        holder.binding.itemName.setText(Data.getJobTitle());

        holder.binding.Details.setText("Edit");
        holder.binding.Details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                update(Data.getJobTitle(), Data.getRef());
            }
        });

        holder.binding.Open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, EmployeeActivity.class);
                intent.putExtra("HeadLine",Data.getJobTitle());
                intent.putExtra("JobTitleNode",Data.getJobTitleNode());
                intent.putExtra("Node",Node);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder {
        ItemMiningSitesBinding binding;

        public viewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ItemMiningSitesBinding.bind(itemView);
        }
    }

    void update(String name, DatabaseReference ref){

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
        alertDialogBuilder.setTitle("Enter Job Title");

        LayoutInflater inflater = LayoutInflater.from(context);
        View dialogView = inflater.inflate(R.layout.job_title_entry, null);

        final EditText jobTitleEditText = dialogView.findViewById(R.id.jobTitleEditText);
        jobTitleEditText.setText(name);
        Button addButton = dialogView.findViewById(R.id.addButton);

        alertDialogBuilder.setView(dialogView);

        final AlertDialog alertDialog = alertDialogBuilder.create();

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String jobTitle = jobTitleEditText.getText().toString();
                if (!jobTitle.isEmpty()) {

                    ref.setValue(jobTitle);

                    alertDialog.dismiss();
                } else {
                    // Show an error message or handle the case where the input is empty
                }
            }
        });

        alertDialogBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        // Show the AlertDialog
        alertDialog.show();

    }
}
