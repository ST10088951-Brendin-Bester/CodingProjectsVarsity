package com.zrax.miningmanagement.Login;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.zrax.miningmanagement.MiningSites.MainActivity;
import com.zrax.miningmanagement.R;
import com.zrax.miningmanagement.databinding.ActivityLoginBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {
    ActivityLoginBinding binding;
    FirebaseAuth auth = FirebaseAuth.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


   

              binding.buttonSignIn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String email = binding.email.getText().toString();
                        String password = binding.password.getText().toString();


                        if (email.equals("")){
                        } else if (password.equals("")) {
                        }
                        else{
                            sign(email, password);

                        }





                    }
                });


              binding.newSign.setOnClickListener(new View.OnClickListener() {
                  @Override
                  public void onClick(View view) {
                      startActivity(new Intent(LoginActivity.this, SignupActivity.class));
                      finish();
                  }
              });

              binding.forgot.setOnClickListener(new View.OnClickListener() {
                  @Override
                  public void onClick(View view) {
                      showPasswordResetDialog(LoginActivity.this);
                  }
              });






            }


            void sign(String email, String password){
                auth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {

                                    Toast.makeText(LoginActivity.this, "Logged in", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(LoginActivity.this, MainActivity.class));
                                    finish();
                                } else {
                                    // Sign in failed, display an error message
                                    String errorMessage = task.getException().getMessage();
                                    Toast.makeText(LoginActivity.this, ""+ errorMessage, Toast.LENGTH_SHORT).show();

                                }
                            }
                        });
            }


    public  void showPasswordResetDialog(Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        View dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_password_reset, null);
        builder.setView(dialogView);

        final EditText emailEditText = dialogView.findViewById(R.id.editTextEmail);

        builder.setPositiveButton("Reset Password", (dialog, which) -> {
            String email = emailEditText.getText().toString().trim();
            resetPassword(email);
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> {
            dialog.cancel();
        });

        builder.create().show();
    }

    private void resetPassword(String email) {
        FirebaseAuth auth = FirebaseAuth.getInstance();
        auth.sendPasswordResetEmail(email)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(LoginActivity.this, "Please check your email", Toast.LENGTH_SHORT).show();

                        // Password reset email sent successfully
                        // Provide feedback to the user as needed
                    } else {
                        // Password reset email sending failed
                        // Handle the error message appropriately
                    }
                });
    }


        }
