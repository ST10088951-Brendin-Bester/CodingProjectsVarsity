package com.zrax.miningmanagement.certificatesList;

public class CertificatesModel {

    String
            CertificateName,ExpiryDate,CertificateUrl
            ,CertificateNode, timestamp, name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public CertificatesModel(String certificateName, String expiryDate, String certificateUrl, String certificateNode) {
        CertificateName = certificateName;
        ExpiryDate = expiryDate;
        CertificateUrl = certificateUrl;
        CertificateNode = certificateNode;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public CertificatesModel() {
    }

    public String getCertificateNode() {
        return CertificateNode;
    }

    public void setCertificateNode(String certificateNode) {
        CertificateNode = certificateNode;
    }

    public String getCertificateName() {
        return CertificateName;
    }

    public void setCertificateName(String certificateName) {
        CertificateName = certificateName;
    }

    public String getExpiryDate() {
        return ExpiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        ExpiryDate = expiryDate;
    }

    public String getCertificateUrl() {
        return CertificateUrl;
    }

    public void setCertificateUrl(String certificateUrl) {
        CertificateUrl = certificateUrl;
    }
}
